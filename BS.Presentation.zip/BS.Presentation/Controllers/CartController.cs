﻿namespace BS.Presentation.Controllers
{
    using BS.Models;
    using BS.Servies;
    using Microsoft.AspNet.Identity;
    using Microsoft.AspNet.Identity.Owin;
    using System;
    using System.Collections.Generic;
    using System.Web.Mvc;

    public class CartController : Controller
    {
        private const string CartSession = "CartSession";
        private UserService userService;
        OrderServices orderServices = new OrderServices();
        public CartController()
        {
            userService = new UserService();
        }
        public ActionResult Index()
        {
            var cart = Session[CartSession];
            var list = new List<CartItem>();
            if (cart != null)
            {
                list = (List<CartItem>)cart;
            }
            else
            {
                ViewBag.Noti = "Giỏ hàng trống!!!";
            }
            return View(list);
        }
        #region additem-cart
        public ActionResult AddItem(int BookId, int quantity)
        {
            var book = new BookServices().GetById(BookId);
            var cart = Session[CartSession];
            if (cart != null)
            {
                var list = (List<CartItem>)cart;
                if (list.Exists(x => x.Books.BookId == BookId))
                {
                    foreach (var item in list)
                    {
                        if (item.Books.BookId == BookId)
                        {
                            item.Quantity += quantity;
                        }
                    }
                }
                else
                {
                    var item = new CartItem();
                    item.Books = book;
                    item.Quantity = quantity;
                    list.Add(item);
                }
                //gan vao session
                Session[CartSession] = list;

            }
            else
            {
                //tao moi gio hang
                var item = new CartItem();
                item.Books = book;
                item.Quantity = quantity;
                var list = new List<CartItem>();

                list.Add(item);
                //gan vao sesssion
                Session[CartSession] = list;
            }

            return RedirectToAction("Index");
        }
        #endregion

        #region delete-cart
        public ActionResult Delete(int id)
        {
            var sessionCart = (List<CartItem>)Session[CartSession];
            sessionCart.RemoveAll(x => x.Books.BookId == id);
            Session[CartSession] = sessionCart;
            if (sessionCart.Count == 0)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return RedirectToAction("Index");
            }

        }
        #endregion

        #region addorder
        public ActionResult Payment()
        {
            if (User.Identity.IsAuthenticated)
            {
                var cart = Session[CartSession];
                List<CartItem> listBook = new List<CartItem>();
                if (cart != null)
                {
                    listBook = (List<CartItem>)cart;
                }

                Order order = new Order();
                order.OrderDate = DateTime.Now;

                string userId = User.Identity.GetUserId();
                order.UserId = userId;

                List<OrderDetail> details = new List<OrderDetail>();

                foreach (var item in listBook)
                {
                    details.Add(new OrderDetail()
                    {
                        OrderId = order.OrderId,
                        BookId = item.Books.BookId,
                        Quantity = item.Quantity

                    });
                }
                try
                {
                    orderServices.AddOrder(order, details);
                    Session[CartSession] = null;
                    return RedirectToAction("Success", "Cart");
                }
                catch (Exception)
                {
                    return RedirectToAction("Error", "Cart");
                }


            }
            else
            {
                return RedirectToAction("Login", "Account");
            }
        }
        #endregion

        public ActionResult Error()
        {
            return View();
        }
        public ActionResult Success()
        {
            return View();
        }
        public ActionResult ThongTinKhachHang()
        {
            string userId = User.Identity.GetUserId();
            var user = userService.GetById(userId);
            return View(user);
        }
        [HttpPost]
        public ActionResult ThongTinKhachHang(ApplicationUser user)
        {
            if (ModelState.IsValid)
            {
                if (User.Identity.IsAuthenticated)
                {
                    var kh = userService.GetById(user.Id);
                    user.PasswordHash = kh.PasswordHash.ToString();
                    user.SecurityStamp = kh.SecurityStamp;

                    userService.Update(user);
                    return RedirectToAction("Payment");

                }
                else
                {
                    return RedirectToAction("Login", "Account");
                }
            }
            else
            {
                return View();
            }
        }
    }
}
