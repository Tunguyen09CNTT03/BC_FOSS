﻿using BS.Servies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BS.Presentation.Controllers
{
    public class BookController : Controller
    {
        BookServices db = new BookServices(); 
        public ActionResult Index(string search, int page = 1, int pageSize = 4)
        {
            var list = db.ListAllPaging(search, page, pageSize);
            ViewBag.Search = search;
            return View(list);
        }

    }
}