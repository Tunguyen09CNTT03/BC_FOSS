﻿using BS.Models;
using BS.Servies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BS.Presentation.Controllers
{
    public class CommentController : Controller
    {
        CommentServices db = new CommentServices();
        public ActionResult Index(int id)
        {
            var list = db.ListCommentByBookId(id);
            if (list != null)
            {
                return View(list);
            }
            return View();
        }

        [HttpPost]
        public ActionResult Insert(Comment comment)
        {
            if (ModelState.IsValid)
            {
                comment.CreateDate = DateTime.Now;
                comment.IsActive = true;
                if (db.Insert(comment) ==1)
                {                   
                    return RedirectToAction("BookDetail", "Home",new { id= comment.BookId});
                }
                else
                {
                    ModelState.AddModelError("", "Comment empty");
                }
            }
            return RedirectToAction("BookDetail", "Home", new { id = comment.BookId });
        }
    }
}