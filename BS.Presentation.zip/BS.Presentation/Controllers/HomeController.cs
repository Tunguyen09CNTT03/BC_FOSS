﻿namespace BS.Presentation.Controllers
{
    using BS.Models;
    using BS.Servies;
    using System.Collections.Generic;
    using System.Web.Mvc;

    public class HomeController : Controller
    {
        private const string CartSession = "CartSession";

        internal BookServices db = new BookServices();

        internal CategoryServices cate = new CategoryServices();

        internal AuthorServcies author = new AuthorServcies();

        internal PublisherServices pub = new PublisherServices();

        public ActionResult Index()
        {
            return View();
        }

        public PartialViewResult Category()
        {
            var list = cate.GetPartialCategory();
            ViewBag.CountCategory = cate.CountCategoryAll();
            return PartialView(list);
        }

        public PartialViewResult Publisher()
        {
            var list = pub.GetPartialPublisher();
            ViewBag.CountPublisher = pub.CountPublisherAll();
            return PartialView(list);
        }

        public PartialViewResult Author()
        {
            var listAuthor = author.GetPartialAuthor();
            ViewBag.CountAuthor = author.CountAuthorAll();
            return PartialView(listAuthor);
        }

        public PartialViewResult Slide()
        {
            return PartialView();
        }

        public PartialViewResult NewBook()
        {
            var newbook = db.GetPartialBook();
            return PartialView(newbook);
        }

        public ActionResult BookDetail(int id)
        {
            var book = db.GetById(id);
            return View(book);
        }

        public PartialViewResult ViewCart()
        {
            var cart = Session[CartSession];
            var list = new List<CartItem>();
            if (cart != null)
            {
                list = (List<CartItem>)cart;
            }
            return PartialView(list);
        }

        public PartialViewResult FuaturesBook()
        {
            var books = db.GetPartialBook();
            return PartialView(books);
        }
        
         
    }
}
