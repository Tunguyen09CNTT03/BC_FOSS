﻿using System;
using System.Threading.Tasks;
using BS.DataAccessLayer;
using BS.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(BS.Presentation.App_Start.Startup))]

namespace BS.Presentation.App_Start
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
            
        }
     
    }
}
