﻿using BS.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace BS.Presentation.App_Start
{
    public class DbSetup
    {
        public static void Initialize()
        {
            Database.SetInitializer(new BookInitializer());

            using (var db = new BookDbContext())
            {
                db.Database.Initialize(true);
            }
        }
    }
}