﻿
namespace BS.Presentation.Areas.Admin.Controllers
{
    using BS.Models;
    using BS.Servies;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Web;
    using System.Web.Mvc;

    [Authorize(Roles = "Admin")]
    public class BookController : Controller
    {
        internal BookServices db = new BookServices();
        CategoryServices cate = new CategoryServices();
        AuthorServcies author = new AuthorServcies();
        PublisherServices pub = new PublisherServices();

        public ActionResult Index(string search, int page = 1, int pageSize = 2)
        {
            var list = db.ListAllPaging(search, page, pageSize);
            ViewBag.Search = search;
            return View(list);
        }

        public ActionResult Create()
        {
            SetViewBag();
            return View();
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Create(Book book, HttpPostedFileBase imageFile)
        {

            if (ModelState.IsValid)
            {
                string fileName = Path.GetFileName(imageFile.FileName);
                string path = Path.Combine(Server.MapPath("~/Image"), fileName);
                imageFile.SaveAs(path);
                book.ImgUrl = fileName;
                book.CreateDate = DateTime.Now;
                db.Insert(book);
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Edit(int id)
        {
            var book = db.GetById(id);
            SetViewBag(id);
            ViewBag.CreateBook = book.CreateDate;
            return View(book);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Edit(Book book, HttpPostedFileBase imageFile)
        {
            if (imageFile != null)
            {
                if (ModelState.IsValid)
                {
                    string fileName = Path.GetFileName(imageFile.FileName);
                    string path = Path.Combine(Server.MapPath("~/Image"), fileName);
                    imageFile.SaveAs(path);
                    book.ImgUrl = fileName;
                    book.ModifierDate = DateTime.Now;
                    db.Update(book);
                    return RedirectToAction("Index");

                }
            }
            else
            {
                book.ModifierDate = DateTime.Now;
                db.Update(book);
                return RedirectToAction("Index");
            }

            return View();
        }

        [HttpDelete]
        public ActionResult Delete(int id)
        {
            try
            {
                db.Delete(id);
                return RedirectToAction("Index");
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void SetViewBag(int? selectedId = null)
        {
            ViewBag.CateId = new SelectList(cate.GetAll(), "CateId", "CateName", selectedId);
            ViewBag.AuthorId = new SelectList(author.GetAll(), "AuthorId", "AuthorName", selectedId);
            ViewBag.PubId = new SelectList(pub.GetAll(), "PubId", "Name", selectedId);
        }

    }
}