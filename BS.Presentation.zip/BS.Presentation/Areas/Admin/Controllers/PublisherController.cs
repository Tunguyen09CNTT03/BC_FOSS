﻿
namespace BS.Presentation.Areas.Admin.Controllers
{
    using BS.Models;
    using BS.Servies;
    using System;
    using System.Web.Mvc;

    [Authorize(Roles = "Admin")]
    public class PublisherController : Controller
    {
        internal PublisherServices db = new PublisherServices();

        public ActionResult Index(string search, int page =1, int pageSize=2)
        {
            var list = db.ListAllPaging(search, page, pageSize);
            ViewBag.search = search;
            return View(list);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Publisher publisher)
        {
            if (ModelState.IsValid)
            {
                db.Insert(publisher);
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Edit(int id)
        {
            var publisher = db.GetById(id);
            return View(publisher);
        }

        [HttpPost]
        public ActionResult Edit(Publisher publisher)
        {
            if (ModelState.IsValid)
            {
                db.Update(publisher);
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpDelete]
        public ActionResult Delete(int id)
        {
            try
            {
                db.Delete(id);
                return RedirectToAction("Index");
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
