﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BS.Servies;

namespace BS.Presentation.Areas.Admin.Controllers
{
    [Authorize(Roles = "Admin")]
    public class OrderController : Controller
    {

        OrderDetailServices detail = new OrderDetailServices();
        public ActionResult Index(string search,int page = 1 , int pageSize =2 )
        {
            var list = detail.ListAllPaging(search, page, pageSize);
            ViewBag.Search = search;
            return View(list);
        }
    }
}