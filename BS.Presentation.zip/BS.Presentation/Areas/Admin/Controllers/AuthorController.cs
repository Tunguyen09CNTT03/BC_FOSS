﻿namespace BS.Presentation.Areas.Admin.Controllers
{
    using BS.Models;
    using BS.Servies;
    using System;
    using System.Web.Mvc;
    [Authorize(Roles ="Admin")]
    public class AuthorController : Controller
    {
        internal AuthorServcies db = new AuthorServcies();
        [Authorize]
        public ActionResult Index(string search, int page = 1, int pageSize = 2)
        {

            var list = db.ListAllPaging(search, page, pageSize);
            ViewBag.Search = search;
            return View(list);
        }
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Author author)
        {
            if (ModelState.IsValid)
            {
                db.Insert(author);
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Edit(int id)
        {
            var author = db.GetById(id);
            return View(author);
        }

        [HttpPost]
        public ActionResult Edit(Author author)
        {
            if (ModelState.IsValid)
            {
                db.Update(author);
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpDelete]
        public ActionResult Delete(int id)
        {
            try
            {
                db.Delete(id);
                return RedirectToAction("Index");
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
