﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BS.Presentation.Areas.Admin.Controllers
{
    [Authorize(Roles = "Admin")]
    public class HomeAdminController : Controller
    {
        Servies.PublisherServices publisher = new Servies.PublisherServices();
        Servies.AuthorServcies author = new Servies.AuthorServcies();
        Servies.CategoryServices category = new Servies.CategoryServices();
        Servies.OrderServices order = new Servies.OrderServices();
        public ActionResult Index()
        {
            if (User.Identity.IsAuthenticated && User.IsInRole("Admin"))
            {
                TempData["CountPublisher"] = publisher.CountPublisherAll();
                TempData["CountAuthor"] = author.CountAuthorAll();
                TempData["CountCategory"] = category.CountCategoryAll();
                TempData["CountOrder"] = order.CountOrder();
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Login");
            }
            
        }
    }
}